self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f74207b0f9037c8b115261908205e8ff",
    "url": "/index.html"
  },
  {
    "revision": "45d4912da013e7a8b0f2",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "af7e913f196e62559ca7",
    "url": "/static/css/main.7135c7b0.chunk.css"
  },
  {
    "revision": "45d4912da013e7a8b0f2",
    "url": "/static/js/2.40eee612.chunk.js"
  },
  {
    "revision": "29eb69a08ea4198f7b46e1db8a3d5045",
    "url": "/static/js/2.40eee612.chunk.js.LICENSE.txt"
  },
  {
    "revision": "af7e913f196e62559ca7",
    "url": "/static/js/main.6076aef0.chunk.js"
  },
  {
    "revision": "27319046b6ff0da48e2c",
    "url": "/static/js/runtime-main.d9161c59.js"
  },
  {
    "revision": "ade49936e18d2ec4cfe17cafe75f4fde",
    "url": "/static/media/6.ade49936.svg"
  },
  {
    "revision": "07d1a425ccbad19329db2f72d12c4233",
    "url": "/static/media/OpenSans-Regular.07d1a425.eot"
  },
  {
    "revision": "3ed9575dcc488c3e3a5bd66620bdf5a4",
    "url": "/static/media/OpenSans-Regular.3ed9575d.ttf"
  },
  {
    "revision": "67e0ecdd8281f64dca1f619b3ae0d32e",
    "url": "/static/media/OpenSans-Regular.67e0ecdd.woff"
  },
  {
    "revision": "d81149cedba60a5acdaeec7d6d4bfa05",
    "url": "/static/media/analyze-bg-large.d81149ce.png"
  },
  {
    "revision": "aace8337b031e796eba4f9fbec8b71e7",
    "url": "/static/media/analyze-bg.aace8337.png"
  },
  {
    "revision": "fa0bafe2259ac12cceca6c7177b5ad07",
    "url": "/static/media/cat.fa0bafe2.png"
  },
  {
    "revision": "d2d29221ad4e0e7b62b6cd64cd8e404e",
    "url": "/static/media/logo.d2d29221.png"
  },
  {
    "revision": "0f79e4bb837c9579950a72b92831071f",
    "url": "/static/media/main-bg.0f79e4bb.png"
  },
  {
    "revision": "7705653c88e410c47255117803e5c6b9",
    "url": "/static/media/main.7705653c.png"
  },
  {
    "revision": "59ee053cf23fe63ceb9ef403cfd4f5cc",
    "url": "/static/media/mobile-start-background.59ee053c.png"
  },
  {
    "revision": "9e5129304c47c0e464baa2d9f20321b9",
    "url": "/static/media/notes-large-left.9e512930.png"
  },
  {
    "revision": "395d9492beb49e8c7bf33e987a25a2f8",
    "url": "/static/media/notes-large-right.395d9492.png"
  },
  {
    "revision": "e24bfac7cc3c46a3ff7361a81de9c8d1",
    "url": "/static/media/notes-left.e24bfac7.png"
  },
  {
    "revision": "4b19d768e60870a2a0fd527d410d14ad",
    "url": "/static/media/notes-m-b-l.4b19d768.svg"
  },
  {
    "revision": "d3f302870402899676ab66bba51c33d2",
    "url": "/static/media/notes-m-b-r.d3f30287.svg"
  },
  {
    "revision": "445a8c2002642a9fb383d88c09a95352",
    "url": "/static/media/notes-m-t-l.445a8c20.svg"
  },
  {
    "revision": "e4a828d35031a8929f50866448b47012",
    "url": "/static/media/notes-m-t-r.e4a828d3.svg"
  },
  {
    "revision": "97f7d190b66d9e1765301cc017b913f9",
    "url": "/static/media/notes-right.97f7d190.png"
  },
  {
    "revision": "60226f5ac6874c07ec0b54ca3cf52e26",
    "url": "/static/media/notes-share-top-left.60226f5a.svg"
  },
  {
    "revision": "170cc1c32a8383d28b26727a3fb69c80",
    "url": "/static/media/notes-share-top-right.170cc1c3.svg"
  },
  {
    "revision": "40289d466b7a4c8da1d8309eb8928ee5",
    "url": "/static/media/plainscriptctt.40289d46.svg"
  },
  {
    "revision": "43f53c87ee27c41917ab24d72c3b5222",
    "url": "/static/media/plainscriptctt.43f53c87.ttf"
  },
  {
    "revision": "b9dec17fe653ba5ecea21c3711670370",
    "url": "/static/media/plainscriptctt.b9dec17f.eot"
  },
  {
    "revision": "d20583f8af6015195cb267ced8e03cd4",
    "url": "/static/media/plainscriptctt.d20583f8.woff2"
  },
  {
    "revision": "e8e32e054ad52b39a4537f64bde31f4c",
    "url": "/static/media/plainscriptctt.e8e32e05.woff"
  },
  {
    "revision": "dbb777ccd6724086726a5023970ff970",
    "url": "/static/media/result-cover.dbb777cc.png"
  },
  {
    "revision": "672fa171938635a9e31d639c009663d3",
    "url": "/static/media/share-footer-bg.672fa171.svg"
  },
  {
    "revision": "ceb4b604c9b6054f77770368bb08e558",
    "url": "/static/media/share-footer-m.ceb4b604.svg"
  }
]);